import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Trash2, r as BookOpen } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-5FwfT0UN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var THEMES = [
	"Віра та Надія",
	"Любов, Милосердя та Прощення",
	"Мудрість та Знання",
	"Молитва",
	"Мужність та Терпіння",
	"Дисципліна",
	"Вдячність та Радість",
	"Сім'я",
	"Смирення",
	"Покаяння",
	"Інше"
];
var KEY = "dukhovnyi-notatnyk.v1";
var MONTHS = [
	"січня",
	"лютого",
	"березня",
	"квітня",
	"травня",
	"червня",
	"липня",
	"серпня",
	"вересня",
	"жовтня",
	"листопада",
	"грудня"
];
var themeSet = new Set(THEMES);
function formatQuoteDate(timestamp) {
	const date = new Date(timestamp);
	return `${date.getDate()} ${MONTHS[date.getMonth()]} ${date.getFullYear()}`;
}
function asTheme(value) {
	return typeof value === "string" && themeSet.has(value) ? value : "Інше";
}
function isQuote(value) {
	if (!value || typeof value !== "object") return false;
	const item = value;
	if (typeof item.id !== "string" || typeof item.text !== "string" || typeof item.source !== "string" || typeof item.createdAt !== "number") return false;
	item.theme = asTheme(item.theme);
	return true;
}
function sortNewest(quotes) {
	return quotes.sort((a, b) => b.createdAt - a.createdAt);
}
function loadQuotes() {
	if (typeof window === "undefined") return [];
	try {
		const raw = window.localStorage.getItem(KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		if (!Array.isArray(parsed)) return [];
		return sortNewest(parsed.filter(isQuote));
	} catch {
		return [];
	}
}
function saveQuotes(quotes) {
	window.localStorage.setItem(KEY, JSON.stringify(quotes));
}
function parseBackup(raw) {
	try {
		const parsed = JSON.parse(raw);
		const list = Array.isArray(parsed) ? parsed : parsed && typeof parsed === "object" && Array.isArray(parsed.quotes) ? parsed.quotes : null;
		if (!list) return null;
		return sortNewest(list.filter(isQuote));
	} catch {
		return null;
	}
}
function quoteClipboard(quote) {
	return quote.source ? `${quote.text}\n— ${quote.source}` : quote.text;
}
function matchesFilters(quote, query, theme) {
	if (theme && theme !== "all" && quote.theme !== theme) return false;
	const needle = query.trim().toLocaleLowerCase("uk");
	if (!needle) return true;
	return quote.text.toLocaleLowerCase("uk").includes(needle) || quote.source.toLocaleLowerCase("uk").includes(needle) || quote.theme.toLocaleLowerCase("uk").includes(needle);
}
function Home() {
	const [quotes, setQuotes] = (0, import_react.useState)([]);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [text, setText] = (0, import_react.useState)("");
	const [source, setSource] = (0, import_react.useState)("");
	const [theme, setTheme] = (0, import_react.useState)("Інше");
	const [query, setQuery] = (0, import_react.useState)("");
	const [themeFilter, setThemeFilter] = (0, import_react.useState)("all");
	const [error, setError] = (0, import_react.useState)("");
	const [notice, setNotice] = (0, import_react.useState)("");
	const [copiedId, setCopiedId] = (0, import_react.useState)("");
	const fileRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setQuotes(loadQuotes());
		setReady(true);
	}, []);
	const visible = (0, import_react.useMemo)(() => quotes.filter((quote) => matchesFilters(quote, query, themeFilter)), [
		quotes,
		query,
		themeFilter
	]);
	function persist(next) {
		setQuotes(next);
		saveQuotes(next);
	}
	function addQuote() {
		const body = text.trim();
		if (!body) {
			setError("Запишіть цитату, перш ніж зберігати.");
			return;
		}
		persist([{
			id: crypto.randomUUID(),
			text: body,
			source: source.trim().replace(/\s+/g, " "),
			theme,
			createdAt: Date.now()
		}, ...quotes]);
		setText("");
		setSource("");
		setError("");
		setNotice("");
	}
	function removeQuote(quote) {
		if (!window.confirm("Видалити цю цитату?")) return;
		persist(quotes.filter((item) => item.id !== quote.id));
	}
	async function copyQuote(quote) {
		const payload = quoteClipboard(quote);
		let ok = false;
		try {
			await navigator.clipboard.writeText(payload);
			ok = true;
		} catch {
			const area = document.createElement("textarea");
			area.value = payload;
			area.setAttribute("readonly", "");
			document.body.appendChild(area);
			area.select();
			ok = document.execCommand("copy");
			area.remove();
		}
		if (!ok) {
			setNotice("Не вдалося скопіювати. Спробуйте ще раз.");
			return;
		}
		setCopiedId(quote.id);
		window.setTimeout(() => setCopiedId((current) => current === quote.id ? "" : current), 1600);
	}
	function downloadBackup() {
		const blob = new Blob([JSON.stringify(quotes, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = "dukhovnyi-notatnyk.json";
		link.click();
		URL.revokeObjectURL(url);
		setNotice("Файл резервної копії завантажено.");
	}
	function restoreFile(file) {
		const reader = new FileReader();
		reader.onload = () => {
			const parsed = parseBackup(String(reader.result ?? ""));
			if (!parsed) {
				setNotice("Цей файл не є резервною копією нотатника.");
				return;
			}
			if (quotes.length > 0 && !window.confirm("Замінити поточні цитати цією копією?")) return;
			persist(parsed);
			setNotice(`Відновлено записів: ${parsed.length}.`);
		};
		reader.readAsText(file);
	}
	const heading = !ready ? "Цитати" : query.trim() || themeFilter !== "all" ? visible.length === 0 ? "Нічого не знайдено" : `Знайдено ${visible.length}` : quotes.length === 0 ? "Ще немає записів" : `Записів: ${quotes.length}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "safe-pad mx-auto min-h-screen w-full max-w-lg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-md border border-border text-accent gold-glow",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, {
						className: "size-5",
						"aria-hidden": "true"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-accent",
					children: "особистий збірник"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl leading-tight font-semibold text-foreground",
					children: "Духовний Нотатник"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-muted",
				children: "Цитати, джерела й теми. Усе лишається лише на цьому пристрої."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "sr-only",
					children: "Пошук"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (event) => setQuery(event.target.value),
					placeholder: "Пошук за словом або джерелом",
					className: "field h-12 px-4 text-base",
					type: "search",
					enterKeyHint: "search"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "sr-only",
					children: "Фільтр за темою"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: themeFilter,
					onChange: (event) => setThemeFilter(event.target.value),
					className: "field h-12 px-4 text-base",
					"aria-label": "Фільтр за темою",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "all",
						children: "Усі теми"
					}), THEMES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: item,
						children: item
					}, item))]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "quote-card mt-4 rounded-card border border-border bg-surface p-4",
				onSubmit: (event) => {
					event.preventDefault();
					addQuote();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "block text-sm text-accent",
						htmlFor: "quote-text",
						children: "Цитата"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						id: "quote-text",
						value: text,
						maxLength: 4e3,
						onChange: (event) => {
							setText(event.target.value);
							if (error) setError("");
						},
						placeholder: "Вставте або запишіть слова…",
						className: "field mt-2 min-h-36 px-4 py-3 text-base leading-relaxed"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mt-4 block text-sm text-accent",
						htmlFor: "quote-source",
						children: "Джерело"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "quote-source",
						value: source,
						maxLength: 160,
						onChange: (event) => setSource(event.target.value),
						placeholder: "Книга, глава, вірш або автор",
						className: "field mt-2 h-12 px-4 text-base"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mt-4 block text-sm text-accent",
						htmlFor: "quote-theme",
						children: "Тема"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						id: "quote-theme",
						value: theme,
						onChange: (event) => setTheme(event.target.value),
						className: "field mt-2 h-12 px-4 text-base",
						children: THEMES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item,
							children: item
						}, item))
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "btn gold-glow mt-4 inline-flex h-12 w-full items-center justify-center rounded-md bg-accent px-4 text-base font-semibold text-accent-fg",
						children: "Зберегти"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				"aria-live": "polite",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm text-muted",
						children: heading
					}),
					ready && quotes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-base leading-relaxed text-muted",
						children: "Перша цитата з’явиться тут карткою, щойно ви її збережете."
					}) : null,
					ready && quotes.length > 0 && visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-base text-muted",
						children: "Спробуйте інше слово або тему."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 flex flex-col gap-3",
						children: visible.map((quote) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "quote-card rounded-card border border-border bg-surface p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
										className: "text-sm text-accent",
										dateTime: new Date(quote.createdAt).toISOString(),
										children: formatQuoteDate(quote.createdAt)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-right text-sm text-accent",
										children: quote.theme
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
									className: "mt-3 text-lg leading-relaxed break-words text-foreground italic whitespace-pre-wrap",
									children: quote.text
								}),
								quote.source ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-4 text-sm text-muted",
									children: ["— ", quote.source]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "btn gold-glow inline-flex h-12 flex-1 items-center justify-center rounded-md bg-accent px-4 text-base font-semibold text-accent-fg",
										onClick: () => void copyQuote(quote),
										children: copiedId === quote.id ? "Скопійовано" : "Копіювати"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "btn inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-md border border-border text-accent",
										"aria-label": "Видалити цитату",
										onClick: () => removeQuote(quote),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
											className: "size-5",
											"aria-hidden": "true"
										})
									})]
								})
							]
						}) }, quote.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm text-muted",
						children: "Резервна копія"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn gold-glow inline-flex h-12 w-full items-center justify-center rounded-md bg-accent px-4 text-base font-semibold text-accent-fg",
						onClick: downloadBackup,
						children: "Зберегти резервну копію у файл"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn inline-flex h-12 w-full items-center justify-center rounded-md border border-border bg-surface px-4 text-base font-semibold text-foreground",
						onClick: () => fileRef.current?.click(),
						children: "Відновити з файлу"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						type: "file",
						accept: "application/json,.json",
						className: "sr-only",
						onChange: (event) => {
							const file = event.target.files?.[0];
							event.target.value = "";
							if (file) restoreFile(file);
						}
					}),
					notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: notice
					}) : null
				]
			})
		]
	});
}
//#endregion
export { Home as component };

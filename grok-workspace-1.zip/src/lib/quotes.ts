export const THEMES = [
  "Віра та Надія",
  "Любов, Милосердя та Прощення",
  "Мудрість та Знання",
  "Молитва",
  "Мужність та Терпіння",
  "Дисципліна",
  "Вдячність та Радість",
  "Сім'я",
  "Смирення",
  "Покаяння",
  "Інше",
] as const;

export type Theme = (typeof THEMES)[number];

export type Quote = {
  id: string;
  text: string;
  source: string;
  theme: Theme;
  createdAt: number;
};

const KEY = "dukhovnyi-notatnyk.v1";

const MONTHS = [
  "січня",
  "лютого",
  "березня",
  "квітня",
  "травня",
  "червня",
  "липня",
  "серпня",
  "вересня",
  "жовтня",
  "листопада",
  "грудня",
];

const themeSet = new Set<string>(THEMES);

export function formatQuoteDate(timestamp: number) {
  const date = new Date(timestamp);
  return `${date.getDate()} ${MONTHS[date.getMonth()]} ${date.getFullYear()}`;
}

function asTheme(value: unknown): Theme {
  return typeof value === "string" && themeSet.has(value) ? (value as Theme) : "Інше";
}

function isQuote(value: unknown): value is Quote {
  if (!value || typeof value !== "object") return false;
  const item = value as Partial<Quote>;
  if (
    typeof item.id !== "string" ||
    typeof item.text !== "string" ||
    typeof item.source !== "string" ||
    typeof item.createdAt !== "number"
  ) {
    return false;
  }
  item.theme = asTheme(item.theme);
  return true;
}

function sortNewest(quotes: Quote[]) {
  return quotes.sort((a, b) => b.createdAt - a.createdAt);
}

export function loadQuotes(): Quote[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return sortNewest(parsed.filter(isQuote));
  } catch {
    return [];
  }
}

export function saveQuotes(quotes: Quote[]) {
  window.localStorage.setItem(KEY, JSON.stringify(quotes));
}

export function parseBackup(raw: string): Quote[] | null {
  try {
    const parsed: unknown = JSON.parse(raw);
    const list = Array.isArray(parsed)
      ? parsed
      : parsed && typeof parsed === "object" && Array.isArray((parsed as { quotes?: unknown }).quotes)
        ? (parsed as { quotes: unknown[] }).quotes
        : null;
    if (!list) return null;
    return sortNewest(list.filter(isQuote));
  } catch {
    return null;
  }
}

export function quoteClipboard(quote: Quote) {
  return quote.source ? `${quote.text}\n— ${quote.source}` : quote.text;
}

export function matchesFilters(quote: Quote, query: string, theme: string) {
  if (theme && theme !== "all" && quote.theme !== theme) return false;
  const needle = query.trim().toLocaleLowerCase("uk");
  if (!needle) return true;
  return (
    quote.text.toLocaleLowerCase("uk").includes(needle) ||
    quote.source.toLocaleLowerCase("uk").includes(needle) ||
    quote.theme.toLocaleLowerCase("uk").includes(needle)
  );
}

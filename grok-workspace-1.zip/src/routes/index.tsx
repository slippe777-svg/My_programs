import { createFileRoute } from "@tanstack/react-router";
import { BookOpen, Trash2 } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  THEMES,
  formatQuoteDate,
  loadQuotes,
  matchesFilters,
  parseBackup,
  quoteClipboard,
  saveQuotes,
  type Quote,
  type Theme,
} from "@/lib/quotes";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [ready, setReady] = useState(false);
  const [text, setText] = useState("");
  const [source, setSource] = useState("");
  const [theme, setTheme] = useState<Theme>("Інше");
  const [query, setQuery] = useState("");
  const [themeFilter, setThemeFilter] = useState("all");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [copiedId, setCopiedId] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setQuotes(loadQuotes());
    setReady(true);
  }, []);

  const visible = useMemo(
    () => quotes.filter((quote) => matchesFilters(quote, query, themeFilter)),
    [quotes, query, themeFilter],
  );

  function persist(next: Quote[]) {
    setQuotes(next);
    saveQuotes(next);
  }

  function addQuote() {
    const body = text.trim();
    if (!body) {
      setError("Запишіть цитату, перш ніж зберігати.");
      return;
    }
    const next: Quote = {
      id: crypto.randomUUID(),
      text: body,
      source: source.trim().replace(/\s+/g, " "),
      theme,
      createdAt: Date.now(),
    };
    persist([next, ...quotes]);
    setText("");
    setSource("");
    setError("");
    setNotice("");
  }

  function removeQuote(quote: Quote) {
    if (!window.confirm("Видалити цю цитату?")) return;
    persist(quotes.filter((item) => item.id !== quote.id));
  }

  async function copyQuote(quote: Quote) {
    const payload = quoteClipboard(quote);
    let ok = false;
    try {
      await navigator.clipboard.writeText(payload);
      ok = true;
    } catch {
      const area = document.createElement("textarea");
      area.value = payload;
      area.setAttribute("readonly", "");
      document.body.appendChild(area);
      area.select();
      ok = document.execCommand("copy");
      area.remove();
    }
    if (!ok) {
      setNotice("Не вдалося скопіювати. Спробуйте ще раз.");
      return;
    }
    setCopiedId(quote.id);
    window.setTimeout(() => setCopiedId((current) => (current === quote.id ? "" : current)), 1600);
  }

  function downloadBackup() {
    const blob = new Blob([JSON.stringify(quotes, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "dukhovnyi-notatnyk.json";
    link.click();
    URL.revokeObjectURL(url);
    setNotice("Файл резервної копії завантажено.");
  }

  function restoreFile(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      const parsed = parseBackup(String(reader.result ?? ""));
      if (!parsed) {
        setNotice("Цей файл не є резервною копією нотатника.");
        return;
      }
      if (quotes.length > 0 && !window.confirm("Замінити поточні цитати цією копією?")) return;
      persist(parsed);
      setNotice(`Відновлено записів: ${parsed.length}.`);
    };
    reader.readAsText(file);
  }

  const heading = !ready
    ? "Цитати"
    : query.trim() || themeFilter !== "all"
      ? visible.length === 0
        ? "Нічого не знайдено"
        : `Знайдено ${visible.length}`
      : quotes.length === 0
        ? "Ще немає записів"
        : `Записів: ${quotes.length}`;

  return (
    <main className="safe-pad mx-auto min-h-screen w-full max-w-lg">
      <header className="flex items-start gap-3">
        <span className="mt-1 inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-md border border-border text-accent gold-glow">
          <BookOpen className="size-5" aria-hidden="true" />
        </span>
        <div>
          <p className="text-sm text-accent">особистий збірник</p>
          <h1 className="text-3xl leading-tight font-semibold text-foreground">Духовний Нотатник</h1>
        </div>
      </header>
      <p className="mt-3 text-sm leading-relaxed text-muted">
        Цитати, джерела й теми. Усе лишається лише на цьому пристрої.
      </p>

      <div className="mt-6 grid gap-3">
        <label>
          <span className="sr-only">Пошук</span>
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Пошук за словом або джерелом"
            className="field h-12 px-4 text-base"
            type="search"
            enterKeyHint="search"
          />
        </label>
        <label>
          <span className="sr-only">Фільтр за темою</span>
          <select
            value={themeFilter}
            onChange={(event) => setThemeFilter(event.target.value)}
            className="field h-12 px-4 text-base"
            aria-label="Фільтр за темою"
          >
            <option value="all">Усі теми</option>
            {THEMES.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </select>
        </label>
      </div>

      <form
        className="quote-card mt-4 rounded-card border border-border bg-surface p-4"
        onSubmit={(event) => {
          event.preventDefault();
          addQuote();
        }}
      >
        <label className="block text-sm text-accent" htmlFor="quote-text">
          Цитата
        </label>
        <textarea
          id="quote-text"
          value={text}
          maxLength={4000}
          onChange={(event) => {
            setText(event.target.value);
            if (error) setError("");
          }}
          placeholder="Вставте або запишіть слова…"
          className="field mt-2 min-h-36 px-4 py-3 text-base leading-relaxed"
        />
        <label className="mt-4 block text-sm text-accent" htmlFor="quote-source">
          Джерело
        </label>
        <input
          id="quote-source"
          value={source}
          maxLength={160}
          onChange={(event) => setSource(event.target.value)}
          placeholder="Книга, глава, вірш або автор"
          className="field mt-2 h-12 px-4 text-base"
        />
        <label className="mt-4 block text-sm text-accent" htmlFor="quote-theme">
          Тема
        </label>
        <select
          id="quote-theme"
          value={theme}
          onChange={(event) => setTheme(event.target.value as Theme)}
          className="field mt-2 h-12 px-4 text-base"
        >
          {THEMES.map((item) => (
            <option key={item} value={item}>
              {item}
            </option>
          ))}
        </select>
        {error ? <p className="mt-3 text-sm text-muted">{error}</p> : null}
        <button
          type="submit"
          className="btn gold-glow mt-4 inline-flex h-12 w-full items-center justify-center rounded-md bg-accent px-4 text-base font-semibold text-accent-fg"
        >
          Зберегти
        </button>
      </form>

      <section className="mt-8" aria-live="polite">
        <h2 className="text-sm text-muted">{heading}</h2>

        {ready && quotes.length === 0 ? (
          <p className="mt-3 text-base leading-relaxed text-muted">
            Перша цитата з’явиться тут карткою, щойно ви її збережете.
          </p>
        ) : null}

        {ready && quotes.length > 0 && visible.length === 0 ? (
          <p className="mt-3 text-base text-muted">Спробуйте інше слово або тему.</p>
        ) : null}

        <ul className="mt-4 flex flex-col gap-3">
          {visible.map((quote) => (
            <li key={quote.id}>
              <article className="quote-card rounded-card border border-border bg-surface p-4">
                <div className="flex items-start justify-between gap-3">
                  <time className="text-sm text-accent" dateTime={new Date(quote.createdAt).toISOString()}>
                    {formatQuoteDate(quote.createdAt)}
                  </time>
                  <span className="text-right text-sm text-accent">{quote.theme}</span>
                </div>
                <blockquote className="mt-3 text-lg leading-relaxed break-words text-foreground italic whitespace-pre-wrap">
                  {quote.text}
                </blockquote>
                {quote.source ? <p className="mt-4 text-sm text-muted">— {quote.source}</p> : null}
                <div className="mt-4 flex gap-2">
                  <button
                    type="button"
                    className="btn gold-glow inline-flex h-12 flex-1 items-center justify-center rounded-md bg-accent px-4 text-base font-semibold text-accent-fg"
                    onClick={() => void copyQuote(quote)}
                  >
                    {copiedId === quote.id ? "Скопійовано" : "Копіювати"}
                  </button>
                  <button
                    type="button"
                    className="btn inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-md border border-border text-accent"
                    aria-label="Видалити цитату"
                    onClick={() => removeQuote(quote)}
                  >
                    <Trash2 className="size-5" aria-hidden="true" />
                  </button>
                </div>
              </article>
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-8 grid gap-3">
        <h2 className="text-sm text-muted">Резервна копія</h2>
        <button
          type="button"
          className="btn gold-glow inline-flex h-12 w-full items-center justify-center rounded-md bg-accent px-4 text-base font-semibold text-accent-fg"
          onClick={downloadBackup}
        >
          Зберегти резервну копію у файл
        </button>
        <button
          type="button"
          className="btn inline-flex h-12 w-full items-center justify-center rounded-md border border-border bg-surface px-4 text-base font-semibold text-foreground"
          onClick={() => fileRef.current?.click()}
        >
          Відновити з файлу
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="application/json,.json"
          className="sr-only"
          onChange={(event) => {
            const file = event.target.files?.[0];
            event.target.value = "";
            if (file) restoreFile(file);
          }}
        />
        {notice ? <p className="text-sm text-muted">{notice}</p> : null}
      </section>
    </main>
  );
}
